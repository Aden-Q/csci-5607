/**
 * @file bump.cpp
 *
 * @copyright 2022 Zecheng Qian, All rights reserved.
 */
#include "bump.h"
#include "color.h"
