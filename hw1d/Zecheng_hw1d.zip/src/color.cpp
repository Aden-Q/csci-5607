/**
 * @file color.cpp
 *
 * @copyright 2022 Zecheng Qian, All rights reserved.
 */
#include "color.h"
