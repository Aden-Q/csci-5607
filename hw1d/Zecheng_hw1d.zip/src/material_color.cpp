/**
 * @file material_color.cpp
 *
 * @copyright 2022 Zecheng Qian, All rights reserved.
 */
#include "material_color.h"
