/**
 * @file texture.cpp
 *
 * @copyright 2022 Zecheng Qian, All rights reserved.
 */
#include "texture.h"
#include "color.h"
