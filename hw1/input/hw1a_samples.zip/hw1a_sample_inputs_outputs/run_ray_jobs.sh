time ./raytracer hw1a_sample1.txt sample1_output.ppm
time ./raytracer hw1a_sample2.txt sample2_output.ppm